
  # Satellite Tracking Dashboard

  This is a code bundle for Satellite Tracking Dashboard. The original project is available at https://www.figma.com/design/SpdGnYpJItw3IVitAcPoki/Satellite-Tracking-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  