import { useState, useEffect } from 'react';
import { RadarDisplay } from './components/RadarDisplay';
import { SatelliteList } from './components/SatelliteList';
import { WeatherBox } from './components/WeatherBox';
import { GPSInfo } from './components/GPSInfo';
import { APRSMap } from './components/APRSMap';
import { DataSourceSelector } from './components/DataSourceSelector';
import { ISSTracker } from './components/ISSTracker';
import { Satellite, Waves, Radio } from 'lucide-react';

interface SatelliteData {
  id: string;
  name: string;
  azimuth: number;
  elevation: number;
  signalStrength: number;
}

// Mock satellite data (in real app, this would come from GPS module or ESP32)
const generateMockSatellites = (): SatelliteData[] => {
  const satelliteNames = [
    'GPS-01', 'GPS-05', 'GPS-12', 'GPS-15', 
    'GPS-20', 'GPS-24', 'GPS-29', 'GLONASS-08',
    'GLONASS-15', 'GALILEO-03', 'GALILEO-11', 'BEIDOU-14',
    'NAVIC-02', 'QZSS-01'
  ];
  
  return satelliteNames.map((name, index) => ({
    id: String(index + 1).padStart(2, '0'),
    name,
    azimuth: Math.random() * 360,
    elevation: Math.random() * 90,
    signalStrength: 15 + Math.random() * 35,
  }));
};

export default function App() {
  const [satellites, setSatellites] = useState<SatelliteData[]>(generateMockSatellites());
  const [currentTime, setCurrentTime] = useState(new Date());
  const [weatherCondition, setWeatherCondition] = useState<'sunny' | 'cloudy' | 'rainy' | 'snowy' | 'windy'>('sunny');
  const [dataSource, setDataSource] = useState<'internet' | 'esp32'>('internet');
  const [esp32Connected, setEsp32Connected] = useState(false);

  // Mock GPS data (in real app, this would come from GPS module or ESP32)
  const gpsData = {
    latitude: 13.0827,
    longitude: 80.2707,
    altitude: 52.3,
  };

  // Mock weather data (in real app from BME280 sensor via ESP32 or API)
  const weatherData = {
    temperature: 28,
    humidity: 72,
    pressure: 1012,
  };

  // Mock ISS data (in real app from tracking API)
  const issData = {
    latitude: 28.5,
    longitude: 77.2,
    altitude: 408.5,
    velocity: 27600,
    visibility: Math.random() > 0.5 ? 'Visible' : 'Not Visible',
  };

  // Update time every second
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // Simulate satellite position updates
  useEffect(() => {
    const interval = setInterval(() => {
      setSatellites((prev) =>
        prev.map((sat) => ({
          ...sat,
          azimuth: (sat.azimuth + Math.random() * 2 - 1 + 360) % 360,
          elevation: Math.max(0, Math.min(90, sat.elevation + Math.random() * 2 - 1)),
          signalStrength: Math.max(10, Math.min(50, sat.signalStrength + Math.random() * 4 - 2)),
        }))
      );
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  // Cycle through weather conditions for demo
  useEffect(() => {
    const conditions: Array<'sunny' | 'cloudy' | 'rainy' | 'snowy' | 'windy'> = ['sunny', 'cloudy', 'rainy', 'snowy', 'windy'];
    let index = 0;
    const interval = setInterval(() => {
      index = (index + 1) % conditions.length;
      setWeatherCondition(conditions[index]);
    }, 10000);
    return () => clearInterval(interval);
  }, []);

  // Simulate ESP32 connection status
  useEffect(() => {
    if (dataSource === 'esp32') {
      // Simulate connection attempt
      const timer = setTimeout(() => {
        setEsp32Connected(Math.random() > 0.3); // 70% success rate for demo
      }, 1000);
      return () => clearTimeout(timer);
    } else {
      setEsp32Connected(false);
    }
  }, [dataSource]);

  const formatLocalTime = (date: Date) => {
    return date.toLocaleString('en-US', {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
  };

  const formatUTCTime = (date: Date) => {
    return date.toUTCString();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-2 md:p-3">
      <div className="max-w-[1920px] mx-auto">
        {/* Header */}
        <div className="mb-2 text-center">
          <div className="flex items-center justify-center gap-2 mb-1">
            <Satellite className="text-green-400" size={24} />
            <h1 className="text-green-400 font-mono text-xl md:text-2xl">SATELLITE & ISS TRACKING</h1>
            <Waves className="text-green-400" size={24} />
          </div>
          <p className="text-green-600 font-mono text-xs">
            Real-time GPS Satellite & ISS Monitoring with Environmental Data
          </p>
        </div>

        {/* Data Source Selector */}
        <div className="mb-2">
          <DataSourceSelector
            source={dataSource}
            onSourceChange={setDataSource}
            esp32Connected={esp32Connected}
          />
        </div>

        {/* Main Content Grid - Optimized for single page view */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-2">
          {/* Left Column - Radar & Satellites */}
          <div className="lg:col-span-1 space-y-2">
            <RadarDisplay satellites={satellites} />
            <div className="h-[280px]">
              <SatelliteList satellites={satellites} />
            </div>
          </div>

          {/* Middle Column - Environmental Data & GPS */}
          <div className="lg:col-span-1 space-y-2">
            <WeatherBox
              condition={weatherCondition}
              temperature={weatherData.temperature}
              humidity={weatherData.humidity}
              pressure={weatherData.pressure}
            />
            <GPSInfo
              latitude={gpsData.latitude}
              longitude={gpsData.longitude}
              altitude={gpsData.altitude}
              dateTime={formatLocalTime(currentTime)}
              utcTime={formatUTCTime(currentTime)}
            />
            <ISSTracker
              latitude={issData.latitude}
              longitude={issData.longitude}
              altitude={issData.altitude}
              velocity={issData.velocity}
              visibility={issData.visibility}
            />
          </div>

          {/* Right Column - APRS Map (Full Height) */}
          <div className="lg:col-span-1 h-[780px]">
            <APRSMap
              latitude={gpsData.latitude}
              longitude={gpsData.longitude}
              callsign="VU3GTG"
            />
          </div>
        </div>

        {/* Footer Info */}
        <div className="mt-2 text-center space-y-2">
          <div className="inline-block bg-black/60 border border-green-500/30 rounded px-3 py-1.5">
            <p className="text-green-600 font-mono text-xs">
              Status: <span className="text-green-400">ACTIVE</span> | 
              Satellites: <span className="text-green-400">{satellites.length}</span> | 
              Source: <span className="text-green-400">{dataSource.toUpperCase()}</span>
              {dataSource === 'esp32' && (
                <> | ESP32: <span className={esp32Connected ? 'text-green-400' : 'text-red-400'}>
                  {esp32Connected ? 'CONNECTED' : 'DISCONNECTED'}
                </span></>
              )}
            </p>
          </div>
          
          {/* VU3 GTG Callsign */}
          <div className="inline-block bg-gradient-to-r from-orange-500/40 to-red-500/40 border-2 border-orange-500/50 rounded-lg px-5 py-2">
            <div className="flex items-center gap-2">
              <Radio className="text-orange-00" size={20} />
              <div>
                <div className="text-orange-400 font-mono text-lg tracking-wider">VU3 GTG</div>
                <div className="text-orange-400/70 text-xs font-mono">Amateur Radio Station</div>
              </div>
              <Radio className="text-orange-400" size={20} />
            </div>
          </div>

          <div className="text-gray-500 text-xs font-mono">
            Compatible with Android | Windows | Mac | iOS
          </div>
        </div>
      </div>
    </div>
  );
}
