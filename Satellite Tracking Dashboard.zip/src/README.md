# 🛰️ Satellite & ISS Tracking System

<div align="center">

![Platform](https://img.shields.io/badge/Platform-Web-blue)
![Compatible](https://img.shields.io/badge/Compatible-Android%20%7C%20iOS%20%7C%20Windows%20%7C%20Mac-green)
![License](https://img.shields.io/badge/License-MIT-yellow)
![Build](https://img.shields.io/badge/Build-Passing-brightgreen)

**Real-time GPS Satellite & ISS Monitoring with Environmental Data**

*Developed by VU3 GTG Amateur Radio Station*

[Features](#-features) • [Installation](#-installation) • [Hardware Setup](#-hardware-setup-esp32) • [Usage](#-usage) • [Deployment](#-deployment)

</div>

---

## 📋 Table of Contents

- [Overview](#-overview)
- [Features](#-features)
- [Screenshots](#-screenshots)
- [Technology Stack](#-technology-stack)
- [Prerequisites](#-prerequisites)
- [Installation](#-installation)
- [Usage](#-usage)
- [Hardware Setup (ESP32)](#-hardware-setup-esp32)
- [Configuration](#-configuration)
- [Deployment](#-deployment)
- [API Integration](#-api-integration)
- [Troubleshooting](#-troubleshooting)
- [Contributing](#-contributing)
- [License](#-license)
- [Credits](#-credits)

---

## 🌟 Overview

This is a comprehensive, cross-platform satellite tracking application that provides real-time monitoring of GPS satellites, International Space Station (ISS), weather conditions, and location data. The system features a rotating radar display, APRS.fi map integration, and supports both internet-based data and ESP32 hardware module connectivity.

### Key Highlights

- 🎯 **Real-time Satellite Tracking** - Track 14+ satellites from GPS, GLONASS, Galileo, BeiDou, NavIC, and QZSS systems
- 🚀 **ISS Tracking** - Monitor International Space Station position, altitude, and velocity
- 🌦️ **Weather Monitoring** - Live temperature, humidity, and atmospheric pressure with animated weather conditions
- 📡 **APRS Integration** - Full APRS.fi map for amateur radio position reporting
- 🔌 **Dual Data Sources** - Works with internet APIs or ESP32 hardware module
- 📱 **Cross-Platform** - Runs on Android, iOS, Windows, Mac, and Linux

---

## ✨ Features

### Satellite Tracking
- ✅ **Rotating Radar Display** - Visual representation with 360° sweep
- ✅ **14 Satellites** - GPS, GLONASS, Galileo, BeiDou, NavIC, QZSS
- ✅ **Color-Coded Signal Strength**
  - 🟢 **Green** - Strong signal (>30 dB)
  - 🟠 **Orange** - Medium signal (15-30 dB)
  - 🔴 **Red** - Weak signal (<15 dB)
- ✅ **Real-time Position Updates** - Azimuth and elevation tracking
- ✅ **Satellite Names** - Displayed directly on radar

### ISS Tracking
- 🛸 Real-time position (latitude/longitude)
- 📏 Current altitude and velocity
- 👁️ Visibility status indicator

### Environmental Data
- 🌡️ Temperature monitoring
- 💧 Humidity percentage
- 🌀 Atmospheric pressure (hPa)
- 🎨 **Animated Weather Boxes**
  - ☀️ Sunny animation
  - ☁️ Cloudy animation
  - 🌧️ Rainy animation
  - ❄️ Snowy animation
  - 💨 Windy animation

### GPS Information
- 📍 Latitude & Longitude (6 decimal precision)
- 📐 Altitude above sea level
- 🕐 Local time with timezone
- 🌍 UTC time

### APRS Integration
- 🗺️ Full APRS.fi interactive map
- 📡 Amateur radio callsign tracking (VU3 GTG)
- 🔄 Real-time position updates

### Hardware Support
- 🔌 Internet mode (API-based data)
- 🎛️ ESP32 module support
- 📊 Live connection status indicator
- 🔧 Automatic data source switching

---

## 📸 Screenshots

### Main Dashboard
The main interface features a 3-column layout:
- **Left Column**: Rotating radar display with satellite dots and scrollable satellite list
- **Middle Column**: Animated weather box, GPS coordinates, and ISS tracker
- **Right Column**: Full-height APRS.fi map with VU3 GTG callsign tracking

### Radar Display
- Circular radar with concentric rings
- Cardinal directions (N, S, E, W)
- Rotating sweep line
- Satellites shown as colored dots with names
- Real-time signal strength visualization

### Data Source Selector
- Toggle between Internet and ESP32 modes
- Visual connection status
- Live status indicators

---

## 🛠️ Technology Stack

### Frontend
- **React 18** - UI framework
- **TypeScript** - Type-safe development
- **Tailwind CSS v4** - Styling
- **Motion (Framer Motion)** - Animations
- **Lucide React** - Icons

### Libraries
- **Canvas API** - Radar display rendering
- **APRS.fi** - Amateur radio tracking
- **Date/Time APIs** - Time synchronization

### Hardware (Optional)
- **ESP32 DevKit V1** - Microcontroller
- **NEO-6M GPS Module** - Satellite positioning
- **BME280 Sensor** - Environmental data (I2C)
- **WiFi** - Wireless data transmission

---

## 📦 Prerequisites

### For Running the Web App
- **Node.js** v18.0.0 or higher
- **npm** v9.0.0 or higher (or **yarn**, **pnpm**)
- Modern web browser (Chrome, Firefox, Safari, Edge)

### For ESP32 Hardware Mode
- **Arduino IDE** v1.8.0 or higher (or PlatformIO)
- **ESP32 Board Support** for Arduino
- **USB-to-Serial Driver** (CH340, CP2102, or FT232)

### Hardware Components (Optional)
- ESP32 DevKit V1 Board
- NEO-6M GPS Module
- BME280 Temperature/Humidity/Pressure Sensor
- Breadboard and jumper wires
- 5V power supply

---

## 🚀 Installation

### Quick Start (Development Mode)

1. **Clone or download the project**
   ```bash
   cd satellite-tracking-system
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start development server**
   ```bash
   npm run dev
   ```

4. **Open in browser**
   ```
   http://localhost:5173
   ```

### Install from Scratch

If you don't have Node.js installed:

1. **Download Node.js**
   - Visit: https://nodejs.org/
   - Download LTS version (v18+)
   - Install with default options

2. **Verify installation**
   ```bash
   node --version
   npm --version
   ```

3. **Follow Quick Start steps above**

---

## 💻 Usage

### Web Application

#### Internet Mode (Default)
1. Launch the application
2. Click **INTERNET** in the Data Source selector
3. View real-time satellite data from web APIs
4. Monitor weather conditions
5. Track ISS position
6. View APRS.fi map

#### ESP32 Hardware Mode
1. Set up ESP32 hardware (see [Hardware Setup](#-hardware-setup-esp32))
2. Click **ESP32** in the Data Source selector
3. Check connection status indicator
4. View real-time data from GPS and BME280 sensors

### Mobile Usage

#### Android
1. Open Chrome browser
2. Navigate to app URL
3. Menu (⋮) → **"Add to Home screen"**
4. App installs as standalone application

#### iOS (iPhone/iPad)
1. Open Safari browser
2. Navigate to app URL
3. Share button → **"Add to Home Screen"**
4. Launch from home screen like native app

#### Desktop Shortcuts

**Windows:**
- Chrome: Menu → "Install app" or "Create shortcut"

**Mac:**
- Safari: Share → "Add to Dock"

---

## 🔌 Hardware Setup (ESP32)

### Required Components

| Component | Quantity | Purpose |
|-----------|----------|---------|
| ESP32 DevKit V1 | 1 | Main microcontroller |
| NEO-6M GPS Module | 1 | Satellite positioning |
| BME280 Sensor | 1 | Weather data (I2C) |
| USB Cable (Micro-USB) | 1 | Programming & power |
| Jumper Wires | 10+ | Connections |
| Breadboard | 1 | Optional prototyping |

### Wiring Diagram

#### NEO-6M GPS Module → ESP32

```
GPS Module          ESP32 Pin
──────────────────────────────
VCC         →       5V
GND         →       GND
TX          →       GPIO3 (RX)
RX          →       GPIO1 (TX)
```

#### BME280 Sensor → ESP32

```
BME280              ESP32 Pin
──────────────────────────────
VCC         →       3.3V
GND         →       GND
SDA         →       GPIO21 (I2C Data)
SCL         →       GPIO22 (I2C Clock)
```

### Visual Connection Summary

```
                    ┌─────────────┐
                    │   ESP32     │
                    │  DevKit V1  │
                    └──────┬──────┘
                           │
          ┌────────────────┼────────────────┐
          │                │                │
    ┌─────▼─────┐    ┌────▼────┐    ┌─────▼─────┐
    │  NEO-6M   │    │ BME280  │    │    USB    │
    │    GPS    │    │ Sensor  │    │  to PC    │
    └───────────┘    └─────────┘    └───────────┘
```

### ESP32 Software Setup

#### 1. Install Arduino IDE

Download from: https://www.arduino.cc/en/software

#### 2. Add ESP32 Board Support

1. Open Arduino IDE
2. Go to **File** → **Preferences**
3. In "Additional Boards Manager URLs", add:
   ```
   https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json
   ```
4. Click **OK**
5. Go to **Tools** → **Board** → **Boards Manager**
6. Search for "ESP32"
7. Install **"ESP32 by Espressif Systems"**

#### 3. Install Required Libraries

Go to **Tools** → **Manage Libraries** and install:
- **TinyGPS++** (by Mikal Hart)
- **Adafruit BME280 Library**
- **Adafruit Unified Sensor**
- **ArduinoJson** (by Benoit Blanchon)
- **WiFi** (built-in)

#### 4. Upload ESP32 Code

Create a new sketch and paste the following code:

```cpp
#include <WiFi.h>
#include <WebServer.h>
#include <TinyGPS++.h>
#include <Adafruit_BME280.h>
#include <ArduinoJson.h>

// ============================================
// CONFIGURATION - UPDATE THESE VALUES
// ============================================
const char* ssid = "YOUR_WIFI_SSID";        // Your WiFi name
const char* password = "YOUR_WIFI_PASSWORD"; // Your WiFi password

// ============================================
// HARDWARE SETUP
// ============================================
TinyGPSPlus gps;
Adafruit_BME280 bme;
WebServer server(8080);
HardwareSerial GPS(1);

// ============================================
// SETUP
// ============================================
void setup() {
  Serial.begin(115200);
  
  // Initialize GPS (RX=GPIO3, TX=GPIO1)
  GPS.begin(9600, SERIAL_8N1, 3, 1);
  
  // Initialize BME280 sensor
  if (!bme.begin(0x76)) {
    Serial.println("Could not find BME280 sensor!");
    Serial.println("Check wiring or try address 0x77");
  }
  
  // Connect to WiFi
  Serial.print("Connecting to WiFi");
  WiFi.begin(ssid, password);
  
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  
  Serial.println("\nWiFi Connected!");
  Serial.print("IP Address: ");
  Serial.println(WiFi.localIP());
  Serial.println("Copy this IP to your web app");
  
  // Setup web server endpoints
  server.on("/data", HTTP_GET, handleData);
  server.enableCORS(true);
  server.begin();
  
  Serial.println("ESP32 Server Started on port 8080");
}

// ============================================
// MAIN LOOP
// ============================================
void loop() {
  server.handleClient();
  
  // Read GPS data
  while (GPS.available() > 0) {
    char c = GPS.read();
    gps.encode(c);
  }
}

// ============================================
// API ENDPOINT - /data
// ============================================
void handleData() {
  StaticJsonDocument<1024> doc;
  
  // GPS Data
  if (gps.location.isValid()) {
    doc["latitude"] = gps.location.lat();
    doc["longitude"] = gps.location.lng();
    doc["altitude"] = gps.altitude.meters();
    doc["satellites"] = gps.satellites.value();
    doc["hdop"] = gps.hdop.hdop();
  } else {
    doc["latitude"] = 0.0;
    doc["longitude"] = 0.0;
    doc["altitude"] = 0.0;
    doc["satellites"] = 0;
  }
  
  // Date & Time
  if (gps.date.isValid() && gps.time.isValid()) {
    char dateStr[32];
    sprintf(dateStr, "%04d-%02d-%02d %02d:%02d:%02d",
            gps.date.year(), gps.date.month(), gps.date.day(),
            gps.time.hour(), gps.time.minute(), gps.time.second());
    doc["datetime"] = dateStr;
  }
  
  // Weather Data from BME280
  doc["temperature"] = bme.readTemperature();
  doc["humidity"] = bme.readHumidity();
  doc["pressure"] = bme.readPressure() / 100.0F; // Convert Pa to hPa
  
  // System Status
  doc["status"] = "active";
  doc["source"] = "esp32";
  
  // Send JSON response
  String response;
  serializeJson(doc, response);
  
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.send(200, "application/json", response);
  
  // Debug output
  Serial.println("Data sent to client");
}
```

#### 5. Configure and Upload

1. Update WiFi credentials in the code
2. Select **Tools** → **Board** → **ESP32 Dev Module**
3. Select **Tools** → **Port** → (Your COM port)
4. Click **Upload** button
5. Wait for upload to complete

#### 6. Get ESP32 IP Address

1. Open **Tools** → **Serial Monitor**
2. Set baud rate to **115200**
3. Press **RST** button on ESP32
4. Note the IP address displayed (e.g., `192.168.1.100`)

#### 7. Test ESP32 API

Open browser and visit:
```
http://YOUR_ESP32_IP:8080/data
```

You should see JSON data like:
```json
{
  "latitude": 13.0827,
  "longitude": 80.2707,
  "altitude": 52.3,
  "satellites": 8,
  "temperature": 28.5,
  "humidity": 72.0,
  "pressure": 1012.3,
  "status": "active",
  "source": "esp32"
}
```

---

## ⚙️ Configuration

### Update ESP32 IP Address in Web App

Edit `/App.tsx` and modify the ESP32 connection endpoint:

```typescript
// Find this section and update the IP
const ESP32_API_URL = "http://192.168.1.100:8080/data"; // Update this IP
```

### Change APRS Callsign

Edit `/App.tsx`:

```typescript
<APRSMap
  latitude={gpsData.latitude}
  longitude={gpsData.longitude}
  callsign="VU3GTG"  // Change to your callsign
/>
```

And update the footer:

```typescript
<div className="text-orange-400 font-mono text-lg tracking-wider">
  VU3 GTG  {/* Change to your callsign */}
</div>
```

### Adjust Weather Update Interval

In `/App.tsx`, find:

```typescript
// Cycle through weather conditions for demo
useEffect(() => {
  const conditions: Array<'sunny' | 'cloudy' | 'rainy' | 'snowy' | 'windy'> = 
    ['sunny', 'cloudy', 'rainy', 'snowy', 'windy'];
  let index = 0;
  const interval = setInterval(() => {
    index = (index + 1) % conditions.length;
    setWeatherCondition(conditions[index]);
  }, 10000); // Change this value (milliseconds)
  return () => clearInterval(interval);
}, []);
```

### Customize Satellite List

Edit `/App.tsx`:

```typescript
const generateMockSatellites = (): SatelliteData[] => {
  const satelliteNames = [
    'GPS-01', 'GPS-05', 'GPS-12', // Add or remove satellites
    // ... your satellites here
  ];
  // ...
};
```

---

## 🌐 Deployment

### Option 1: Netlify (Recommended)

#### Method A: Netlify CLI

1. **Install Netlify CLI**
   ```bash
   npm install -g netlify-cli
   ```

2. **Build the app**
   ```bash
   npm run build
   ```

3. **Deploy**
   ```bash
   netlify deploy --prod
   ```

4. **Access your app**
   - URL provided: `https://your-app-name.netlify.app`

#### Method B: Netlify Drag & Drop

1. Build the app: `npm run build`
2. Go to https://app.netlify.com/drop
3. Drag the `dist` folder to the upload area
4. Get your live URL

### Option 2: Vercel

1. **Install Vercel CLI**
   ```bash
   npm install -g vercel
   ```

2. **Deploy**
   ```bash
   vercel --prod
   ```

3. **Access your app**
   - URL: `https://your-app.vercel.app`

### Option 3: GitHub Pages

1. **Install gh-pages**
   ```bash
   npm install --save-dev gh-pages
   ```

2. **Add to package.json**
   ```json
   {
     "homepage": "https://YOUR_USERNAME.github.io/YOUR_REPO_NAME",
     "scripts": {
       "predeploy": "npm run build",
       "deploy": "gh-pages -d dist"
     }
   }
   ```

3. **Deploy**
   ```bash
   npm run deploy
   ```

### Option 4: Local Network Access

For accessing from other devices on your network:

1. **Start dev server with network access**
   ```bash
   npm run dev -- --host
   ```

2. **Find your local IP**
   - Windows: `ipconfig`
   - Mac/Linux: `ifconfig` or `ip addr`

3. **Access from any device on same WiFi**
   ```
   http://YOUR_LOCAL_IP:5173
   ```

---

## 🔗 API Integration

### Internet Mode APIs

For production use, integrate these APIs:

#### 1. Satellite Data
- **N2YO.com** - Satellite tracking API
  - Website: https://www.n2yo.com/api/
  - Provides TLE data, satellite positions

#### 2. ISS Tracking
- **Open Notify ISS API**
  - Endpoint: `http://api.open-notify.org/iss-now.json`
  - Free, no API key required

#### 3. Weather Data
- **OpenWeatherMap API**
  - Website: https://openweathermap.org/api
  - Provides temperature, humidity, pressure

#### 4. GPS Location
- **Browser Geolocation API**
  - Built-in browser feature
  - Requires user permission

### Example API Integration

```typescript
// Fetch ISS position
const fetchISSData = async () => {
  try {
    const response = await fetch('http://api.open-notify.org/iss-now.json');
    const data = await response.json();
    return {
      latitude: parseFloat(data.iss_position.latitude),
      longitude: parseFloat(data.iss_position.longitude),
      altitude: 408.5, // ISS average altitude
      velocity: 27600  // ISS average velocity
    };
  } catch (error) {
    console.error('Failed to fetch ISS data:', error);
  }
};
```

---

## 🐛 Troubleshooting

### Common Issues

#### 1. App won't start
**Problem:** `npm run dev` fails

**Solutions:**
```bash
# Clear node modules and reinstall
rm -rf node_modules package-lock.json
npm install

# Try with specific Node version
nvm use 18
npm install
npm run dev
```

#### 2. APRS map not loading
**Problem:** Map shows loading indefinitely

**Solutions:**
- Check internet connection
- Verify APRS.fi is accessible
- Try different callsign format
- Check browser console for CORS errors

#### 3. ESP32 not connecting
**Problem:** ESP32 shows "DISCONNECTED"

**Solutions:**
- Verify WiFi credentials in Arduino code
- Check ESP32 IP address in Serial Monitor
- Ensure ESP32 and computer on same network
- Update IP in web app configuration
- Check firewall settings (allow port 8080)

#### 4. GPS not getting fix
**Problem:** GPS shows 0 satellites

**Solutions:**
- Move GPS module near window or outdoors
- Wait 5-10 minutes for cold start
- Check GPS module antenna connection
- Verify RX/TX pins not swapped
- Check GPS module LED blinking

#### 5. BME280 not found
**Problem:** Arduino shows "Could not find BME280"

**Solutions:**
- Check I2C wiring (SDA, SCL)
- Try address `0x77` instead of `0x76`
- Use I2C scanner to find address
- Verify sensor power (3.3V)

#### 6. Mobile browser can't access
**Problem:** Mobile shows "Cannot connect"

**Solutions:**
- Ensure on same WiFi network
- Use `--host` flag: `npm run dev -- --host`
- Disable computer firewall temporarily
- Use local IP instead of `localhost`

#### 7. Slow performance
**Problem:** App is laggy or slow

**Solutions:**
- Reduce satellite update interval
- Close unused browser tabs
- Try different browser
- Check RAM usage
- Build for production: `npm run build`

---

## 🤝 Contributing

Contributions are welcome! Here's how you can help:

### Reporting Bugs
1. Check existing issues
2. Create new issue with:
   - Clear description
   - Steps to reproduce
   - Expected vs actual behavior
   - Screenshots if applicable

### Feature Requests
1. Open new issue
2. Describe feature clearly
3. Explain use case
4. Provide examples

### Pull Requests
1. Fork the repository
2. Create feature branch: `git checkout -b feature/AmazingFeature`
3. Commit changes: `git commit -m 'Add AmazingFeature'`
4. Push to branch: `git push origin feature/AmazingFeature`
5. Open Pull Request

### Development Guidelines
- Follow existing code style
- Add comments for complex logic
- Test on multiple devices
- Update README if needed

---

## 📄 License

This project is licensed under the **MIT License**.

```
MIT License

Copyright (c) 2025 VU3 GTG

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

---

## 🙏 Credits

### Developer
- **VU3 GTG** - Amateur Radio Station
- Initial development and design

### Technologies Used
- **React** - Facebook
- **TypeScript** - Microsoft
- **Tailwind CSS** - Tailwind Labs
- **Motion** - Framer
- **Lucide Icons** - Lucide

### Hardware
- **ESP32** - Espressif Systems
- **NEO-6M GPS** - u-blox
- **BME280** - Bosch Sensortec

### APIs & Services
- **APRS.fi** - Amateur radio tracking
- **Open Notify** - ISS tracking data
- **OpenWeatherMap** - Weather data

### Special Thanks
- Amateur Radio Community
- Open Source Contributors
- Beta Testers

---

## 📞 Contact & Support

### Issues & Questions
- **GitHub Issues**: [Open an issue](https://github.com/YOUR_USERNAME/satellite-tracking/issues)
- **Discussions**: [GitHub Discussions](https://github.com/YOUR_USERNAME/satellite-tracking/discussions)

### Amateur Radio
- **Callsign**: VU3 GTG
- **APRS**: https://aprs.fi/#!call=a%2FVU3GTG

### Social Media
- Follow for updates and news
- Share your implementations
- Connect with other users

---

## 🗺️ Roadmap

### Planned Features

#### Version 2.0
- [ ] Real API integration (N2YO, OpenWeather)
- [ ] Historical satellite pass predictions
- [ ] Multiple location support
- [ ] Dark mode toggle
- [ ] Export data to CSV

#### Version 2.1
- [ ] Satellite pass notifications
- [ ] Audio alerts for ISS visibility
- [ ] Custom satellite selection
- [ ] Multiple APRS stations tracking
- [ ] Mobile app (React Native)

#### Version 3.0
- [ ] 3D satellite visualization
- [ ] Augmented Reality satellite finder
- [ ] Multi-language support
- [ ] Cloud data synchronization
- [ ] User accounts and preferences

---

## 📊 Project Statistics

- **Lines of Code**: ~2,500+
- **Components**: 9 custom components
- **Satellites Tracked**: 14+
- **Supported Platforms**: 4 (Android, iOS, Windows, Mac)
- **Data Sources**: 2 (Internet, ESP32)
- **Weather Animations**: 5 types

---

## 🎯 Use Cases

### Amateur Radio Operators
- Track APRS positions
- Monitor satellite passes
- Plan communications

### Education
- Learn about GPS technology
- Understand satellite orbits
- Weather data collection

### IoT Projects
- ESP32 integration examples
- Sensor data visualization
- Real-time monitoring systems

### Hobbyists
- DIY satellite tracking
- Weather station building
- Arduino/ESP32 learning

---

## ⚡ Quick Reference

### Development Commands
```bash
npm install          # Install dependencies
npm run dev          # Start dev server
npm run build        # Build for production
npm run preview      # Preview production build
npm run deploy       # Deploy to hosting
```

### ESP32 Serial Monitor
```bash
Baud Rate: 115200
Line Ending: Both NL & CR
```

### Default Ports
- Web App: `5173` (development)
- ESP32 API: `8080`

### Key Files
- Main App: `/App.tsx`
- Components: `/components/`
- Styles: `/styles/globals.css`
- ESP32 Code: See [Hardware Setup](#-hardware-setup-esp32)

---

<div align="center">

**Made with ❤️ by VU3 GTG**

*73 de VU3 GTG* 📡

[⬆ Back to Top](#-satellite--iss-tracking-system)

</div>
