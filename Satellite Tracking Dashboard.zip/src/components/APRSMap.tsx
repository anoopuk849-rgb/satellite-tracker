import { useEffect, useRef, useState } from 'react';
import { motion } from 'motion/react';
import { Map, MapPin, Radio } from 'lucide-react';

interface APRSMapProps {
  latitude: number;
  longitude: number;
  callsign: string;
}

export function APRSMap({ latitude, longitude, callsign }: APRSMapProps) {
  const [mapLoaded, setMapLoaded] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    const timer = setTimeout(() => setMapLoaded(true), 1000);
    return () => clearTimeout(timer);
  }, []);

  // APRS.fi map URL with coordinates
  const aprsUrl = `https://aprs.fi/#!call=a%2F${callsign}&timerange=3600&tail=3600`;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-black/80 rounded-lg border-2 border-orange-500/50 p-3 h-full flex flex-col"
    >
      <div className="flex items-center gap-2 mb-2">
        <Radio className="text-orange-400" size={16} />
        <h3 className="text-orange-400 font-mono text-sm">APRS.FI MAP</h3>
      </div>
      
      <div className="bg-orange-950/30 border border-orange-500/30 rounded p-2 mb-2">
        <div className="flex items-center gap-2">
          <MapPin className="text-orange-400" size={14} />
          <span className="text-orange-300 font-mono text-xs">{callsign}</span>
        </div>
        <div className="text-orange-400/70 text-xs font-mono mt-0.5">
          {latitude.toFixed(4)}°N, {Math.abs(longitude).toFixed(4)}°W
        </div>
      </div>

      <div className="relative bg-slate-900 rounded overflow-hidden flex-1">
        {!mapLoaded && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-orange-400 font-mono text-xs flex items-center gap-2">
              <Map className="animate-pulse" size={16} />
              Loading APRS Map...
            </div>
          </div>
        )}
        <iframe
          ref={iframeRef}
          src={aprsUrl}
          className="w-full h-full border-0"
          title="APRS.fi Map"
          onLoad={() => setMapLoaded(true)}
        />
      </div>

      <div className="mt-2 bg-orange-950/30 border border-orange-500/30 rounded p-2">
        <div className="text-orange-400 text-xs font-mono">
          Real-time APRS Tracking
        </div>
      </div>
    </motion.div>
  );
}
