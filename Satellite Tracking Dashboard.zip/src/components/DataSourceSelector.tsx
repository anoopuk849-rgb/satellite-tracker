import { motion } from 'motion/react';
import { Wifi, Cpu, CheckCircle2 } from 'lucide-react';

interface DataSourceSelectorProps {
  source: 'internet' | 'esp32';
  onSourceChange: (source: 'internet' | 'esp32') => void;
  esp32Connected: boolean;
}

export function DataSourceSelector({ source, onSourceChange, esp32Connected }: DataSourceSelectorProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-black/80 rounded-lg border-2 border-cyan-500/50 p-4"
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-cyan-400 font-mono text-sm">DATA SOURCE</h3>
        <div className={`flex items-center gap-1 px-2 py-1 rounded ${
          esp32Connected ? 'bg-green-900/30 border border-green-500/50' : 'bg-red-900/30 border border-red-500/50'
        }`}>
          <div className={`w-2 h-2 rounded-full ${
            esp32Connected ? 'bg-green-400 animate-pulse' : 'bg-red-400'
          }`} />
          <span className={`text-xs font-mono ${
            esp32Connected ? 'text-green-400' : 'text-red-400'
          }`}>
            {esp32Connected ? 'CONNECTED' : 'DISCONNECTED'}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => onSourceChange('internet')}
          className={`relative p-4 rounded-lg border-2 transition-all ${
            source === 'internet'
              ? 'bg-cyan-900/40 border-cyan-500 shadow-lg shadow-cyan-500/20'
              : 'bg-slate-900/40 border-cyan-500/30 hover:border-cyan-500/50'
          }`}
        >
          <Wifi className={`mx-auto mb-2 ${
            source === 'internet' ? 'text-cyan-400' : 'text-cyan-600'
          }`} size={32} />
          <div className={`font-mono text-sm ${
            source === 'internet' ? 'text-cyan-300' : 'text-cyan-600'
          }`}>
            INTERNET
          </div>
          {source === 'internet' && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="absolute top-2 right-2"
            >
              <CheckCircle2 className="text-cyan-400" size={16} />
            </motion.div>
          )}
        </motion.button>

        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => onSourceChange('esp32')}
          className={`relative p-4 rounded-lg border-2 transition-all ${
            source === 'esp32'
              ? 'bg-purple-900/40 border-purple-500 shadow-lg shadow-purple-500/20'
              : 'bg-slate-900/40 border-purple-500/30 hover:border-purple-500/50'
          }`}
        >
          <Cpu className={`mx-auto mb-2 ${
            source === 'esp32' ? 'text-purple-400' : 'text-purple-600'
          }`} size={32} />
          <div className={`font-mono text-sm ${
            source === 'esp32' ? 'text-purple-300' : 'text-purple-600'
          }`}>
            ESP32
          </div>
          {source === 'esp32' && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="absolute top-2 right-2"
            >
              <CheckCircle2 className="text-purple-400" size={16} />
            </motion.div>
          )}
        </motion.button>
      </div>

      <div className="mt-4 bg-cyan-950/30 border border-cyan-500/30 rounded p-3">
        <div className="text-cyan-400 text-xs font-mono mb-1">
          {source === 'internet' ? 'Using Internet Data' : 'Using ESP32 Module'}
        </div>
        <div className="text-cyan-400/70 text-xs font-mono">
          {source === 'internet' 
            ? 'Fetching data via web APIs' 
            : esp32Connected 
              ? 'Real-time data from ESP32 @ 192.168.1.100' 
              : 'ESP32 module not detected'}
        </div>
      </div>
    </motion.div>
  );
}
