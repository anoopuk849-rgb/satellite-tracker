import { motion } from 'motion/react';
import { Cpu, Wifi } from 'lucide-react';

export function ESP32Diagram() {
  const connections = [
    { esp32: 'TX (GPIO1)', component: 'GPS TX', color: '#3b82f6', label: 'GPS Data' },
    { esp32: 'RX (GPIO3)', component: 'GPS RX', color: '#22c55e', label: 'GPS Control' },
    { esp32: 'GPIO21', component: 'BME280 SDA', color: '#f59e0b', label: 'I2C Data' },
    { esp32: 'GPIO22', component: 'BME280 SCL', color: '#ef4444', label: 'I2C Clock' },
    { esp32: '5V', component: 'Sensors VCC', color: '#ef4444', label: 'Power' },
    { esp32: 'GND', component: 'Common GND', color: '#000000', label: 'Ground' },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gradient-to-br from-purple-950/50 to-slate-900/50 rounded-lg border-2 border-purple-500/50 p-4"
    >
      <div className="flex items-center gap-2 mb-4">
        <Cpu className="text-purple-400" size={20} />
        <h3 className="text-purple-400 font-mono">ESP32 MODULE CONNECTIONS</h3>
      </div>

      <div className="mb-4 bg-purple-950/40 border border-purple-500/30 rounded p-3">
        <div className="text-purple-300 font-mono mb-1">ESP32 DevKit V1</div>
        <div className="text-purple-400/70 text-xs flex items-center gap-2">
          <Wifi size={14} />
          WiFi enabled for wireless data transmission
        </div>
      </div>

      <div className="space-y-2">
        {connections.map((conn, index) => (
          <motion.div
            key={conn.esp32}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-slate-800/50 border border-purple-500/20 rounded p-2"
          >
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <div
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: conn.color }}
                />
                <span className="text-purple-300 font-mono">{conn.esp32}</span>
              </div>
              <div className="text-purple-500/70 font-mono">→ {conn.label}</div>
              <span className="text-purple-400 font-mono">{conn.component}</span>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="mt-4 bg-purple-950/40 border border-purple-500/30 rounded p-3">
        <div className="text-purple-300 text-xs font-mono mb-2">Required Components:</div>
        <div className="space-y-1 text-xs font-mono text-purple-400/80">
          <div>• NEO-6M GPS Module (UART)</div>
          <div>• BME280 Sensor (I2C) - Weather Data</div>
          <div>• ESP32 DevKit V1 Board</div>
          <div>• 5V Power Supply</div>
        </div>
      </div>

      <div className="mt-3 bg-purple-950/40 border border-purple-500/30 rounded p-3">
        <div className="text-purple-300 text-xs font-mono mb-1">WiFi Configuration:</div>
        <div className="text-purple-400/70 text-xs font-mono">
          IP: 192.168.1.100 | Port: 8080
        </div>
      </div>
    </motion.div>
  );
}
