import { motion } from 'motion/react';
import { MapPin, Clock, Gauge } from 'lucide-react';

interface GPSInfoProps {
  latitude: number;
  longitude: number;
  altitude: number;
  dateTime: string;
  utcTime: string;
}

export function GPSInfo({ latitude, longitude, altitude, dateTime, utcTime }: GPSInfoProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-black/80 rounded-lg border-2 border-blue-500/50 p-3"
    >
      <div className="flex items-center gap-2 mb-3">
        <MapPin className="text-blue-400" size={16} />
        <h3 className="text-blue-400 font-mono text-sm">GPS DATA</h3>
      </div>
      <div className="space-y-2">
        <div className="grid grid-cols-2 gap-2">
          <div className="bg-blue-950/30 border border-blue-500/20 rounded p-1.5">
            <div className="text-blue-600 text-xs mb-0.5">Latitude</div>
            <div className="text-blue-300 font-mono text-xs">{latitude.toFixed(6)}°</div>
          </div>
          <div className="bg-blue-950/30 border border-blue-500/20 rounded p-1.5">
            <div className="text-blue-600 text-xs mb-0.5">Longitude</div>
            <div className="text-blue-300 font-mono text-xs">{longitude.toFixed(6)}°</div>
          </div>
        </div>
        <div className="bg-blue-950/30 border border-blue-500/20 rounded p-1.5">
          <div className="flex items-center gap-1">
            <Gauge className="text-blue-400" size={12} />
            <span className="text-blue-600 text-xs">Altitude: </span>
            <span className="text-blue-300 font-mono text-xs">{altitude.toFixed(1)} m</span>
          </div>
        </div>
        <div className="bg-blue-950/30 border border-blue-500/20 rounded p-1.5">
          <div className="flex items-center gap-1 mb-1">
            <Clock className="text-blue-400" size={12} />
            <span className="text-blue-600 text-xs">Local Time</span>
          </div>
          <div className="text-blue-300 font-mono text-xs">{dateTime}</div>
        </div>
        <div className="bg-blue-950/30 border border-blue-500/20 rounded p-1.5">
          <div className="text-blue-600 text-xs mb-1">UTC Time</div>
          <div className="text-blue-300 font-mono text-xs">{utcTime}</div>
        </div>
      </div>
    </motion.div>
  );
}
