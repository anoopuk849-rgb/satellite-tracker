import { motion } from 'motion/react';
import { Cpu, Laptop } from 'lucide-react';

export function GPSModuleDiagram() {
  const connections = [
    { module: 'VCC', laptop: 'USB 5V', color: '#ef4444', label: 'Power (+5V)' },
    { module: 'GND', laptop: 'USB GND', color: '#000000', label: 'Ground' },
    { module: 'TXD', laptop: 'USB RX', color: '#3b82f6', label: 'Transmit' },
    { module: 'RXD', laptop: 'USB TX', color: '#22c55e', label: 'Receive' },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gradient-to-br from-slate-900 to-slate-800 rounded-lg border-2 border-purple-500/50 p-6"
    >
      <div className="flex items-center gap-2 mb-6">
        <Cpu className="text-purple-400" size={20} />
        <h3 className="text-purple-400 font-mono">GPS MODULE CONNECTION</h3>
      </div>

      <div className="mb-4 bg-purple-950/30 border border-purple-500/30 rounded p-3">
        <div className="text-purple-300 font-mono mb-1">Module: NEO-6M GPS Module</div>
        <div className="text-purple-400/70 text-sm">
          USB-to-TTL Serial Adapter Required (CH340, CP2102, or FT232)
        </div>
      </div>

      <div className="flex items-center justify-between gap-8">
        {/* GPS Module */}
        <div className="flex-1">
          <div className="bg-blue-600 text-white text-center py-2 px-4 rounded-t font-mono">
            NEO-6M GPS
          </div>
          <div className="bg-slate-700 border-2 border-blue-500 rounded-b p-4 space-y-2">
            {connections.map((conn, index) => (
              <motion.div
                key={conn.module}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-slate-800 px-3 py-2 rounded font-mono text-sm flex items-center justify-between"
              >
                <span className="text-blue-300">{conn.module}</span>
                <div
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: conn.color }}
                />
              </motion.div>
            ))}
          </div>
        </div>

        {/* Connection Lines */}
        <div className="flex-1 space-y-2">
          {connections.map((conn, index) => (
            <motion.div
              key={conn.label}
              initial={{ scaleX: 0 }}
              animate={{ scaleX: 1 }}
              transition={{ delay: index * 0.1 + 0.2, duration: 0.3 }}
              className="origin-left"
            >
              <div className="flex items-center gap-2">
                <div
                  className="h-0.5 flex-1"
                  style={{ backgroundColor: conn.color }}
                />
                <span className="text-xs text-gray-400 font-mono whitespace-nowrap">
                  {conn.label}
                </span>
                <div
                  className="h-0.5 flex-1"
                  style={{ backgroundColor: conn.color }}
                />
              </div>
            </motion.div>
          ))}
        </div>

        {/* USB Adapter / Laptop */}
        <div className="flex-1">
          <div className="bg-green-600 text-white text-center py-2 px-4 rounded-t font-mono">
            USB-TTL Adapter
          </div>
          <div className="bg-slate-700 border-2 border-green-500 rounded-b p-4 space-y-2">
            {connections.map((conn, index) => (
              <motion.div
                key={conn.laptop}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-slate-800 px-3 py-2 rounded font-mono text-sm flex items-center justify-between"
              >
                <div
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: conn.color }}
                />
                <span className="text-green-300">{conn.laptop}</span>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-6 flex items-center gap-2 justify-center">
        <Laptop className="text-purple-400" size={20} />
        <div className="text-purple-400 font-mono text-sm">
          Connect USB-TTL Adapter to Laptop USB Port
        </div>
      </div>

      <div className="mt-4 bg-purple-950/30 border border-purple-500/30 rounded p-3">
        <div className="text-purple-300 text-sm font-mono mb-2">Pin Configuration:</div>
        <div className="grid grid-cols-2 gap-2 text-xs font-mono">
          <div className="text-purple-400">• VCC: Power Supply (3.3V-5V)</div>
          <div className="text-purple-400">• GND: Ground Reference</div>
          <div className="text-purple-400">• TXD: GPS Data Output</div>
          <div className="text-purple-400">• RXD: GPS Data Input</div>
        </div>
      </div>
    </motion.div>
  );
}
