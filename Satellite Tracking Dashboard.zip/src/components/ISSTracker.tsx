import { motion } from 'motion/react';
import { Rocket, MapPin, Navigation } from 'lucide-react';

interface ISSTrackerProps {
  latitude: number;
  longitude: number;
  altitude: number;
  velocity: number;
  visibility: string;
}

export function ISSTracker({ latitude, longitude, altitude, velocity, visibility }: ISSTrackerProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="bg-gradient-to-br from-indigo-950/50 to-purple-950/50 rounded-lg border-2 border-indigo-500/50 p-3"
    >
      <div className="flex items-center gap-2 mb-3">
        <Rocket className="text-indigo-400" size={18} />
        <h3 className="text-indigo-400 font-mono text-sm">ISS TRACKING</h3>
        <div className={`ml-auto px-2 py-0.5 rounded text-xs font-mono ${
          visibility === 'Visible' 
            ? 'bg-green-900/40 text-green-400 border border-green-500/50' 
            : 'bg-gray-900/40 text-gray-400 border border-gray-500/50'
        }`}>
          {visibility}
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-2 text-xs">
        <div className="bg-indigo-950/40 border border-indigo-500/30 rounded p-2">
          <div className="flex items-center gap-1 text-indigo-600 mb-1">
            <MapPin size={12} />
            <span>Position</span>
          </div>
          <div className="text-indigo-300 font-mono">
            {latitude.toFixed(4)}°N
          </div>
          <div className="text-indigo-300 font-mono">
            {longitude.toFixed(4)}°E
          </div>
        </div>
        
        <div className="bg-indigo-950/40 border border-indigo-500/30 rounded p-2">
          <div className="flex items-center gap-1 text-indigo-600 mb-1">
            <Navigation size={12} />
            <span>Altitude</span>
          </div>
          <div className="text-indigo-300 font-mono">
            {altitude.toFixed(1)} km
          </div>
          <div className="text-indigo-400/70 text-xs">
            {velocity.toFixed(0)} km/h
          </div>
        </div>
      </div>
    </motion.div>
  );
}
