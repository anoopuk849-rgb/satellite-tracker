import { useEffect, useRef, useState } from 'react';
import { motion } from 'motion/react';

interface Satellite {
  id: string;
  name: string;
  azimuth: number;
  elevation: number;
  signalStrength: number;
}

interface RadarDisplayProps {
  satellites: Satellite[];
}

export function RadarDisplay({ satellites }: RadarDisplayProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [rotation, setRotation] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setRotation((prev) => (prev + 1) % 360);
    }, 50);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const radius = Math.min(centerX, centerY) - 40;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw background circles
    ctx.strokeStyle = 'rgba(0, 255, 0, 0.3)';
    ctx.lineWidth = 1;
    for (let i = 1; i <= 4; i++) {
      ctx.beginPath();
      ctx.arc(centerX, centerY, (radius / 4) * i, 0, Math.PI * 2);
      ctx.stroke();
    }

    // Draw crosshairs
    ctx.strokeStyle = 'rgba(0, 255, 0, 0.3)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(centerX, centerY - radius);
    ctx.lineTo(centerX, centerY + radius);
    ctx.moveTo(centerX - radius, centerY);
    ctx.lineTo(centerX + radius, centerY);
    ctx.stroke();

    // Draw cardinal directions
    ctx.fillStyle = '#00ff00';
    ctx.font = '14px monospace';
    ctx.textAlign = 'center';
    ctx.fillText('N', centerX, centerY - radius - 10);
    ctx.fillText('S', centerX, centerY + radius + 20);
    ctx.textAlign = 'left';
    ctx.fillText('E', centerX + radius + 10, centerY + 5);
    ctx.textAlign = 'right';
    ctx.fillText('W', centerX - radius - 10, centerY + 5);

    // Draw rotating sweep line
    ctx.save();
    ctx.translate(centerX, centerY);
    ctx.rotate((rotation * Math.PI) / 180);
    
    const gradient = ctx.createLinearGradient(0, 0, radius, 0);
    gradient.addColorStop(0, 'rgba(0, 255, 0, 0)');
    gradient.addColorStop(0.5, 'rgba(0, 255, 0, 0.3)');
    gradient.addColorStop(1, 'rgba(0, 255, 0, 0.8)');
    
    ctx.strokeStyle = gradient;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(radius, 0);
    ctx.stroke();
    ctx.restore();

    // Draw satellites
    satellites.forEach((sat) => {
      const angle = ((sat.azimuth - 90) * Math.PI) / 180;
      const distance = ((90 - sat.elevation) / 90) * radius;
      const x = centerX + distance * Math.cos(angle);
      const y = centerY + distance * Math.sin(angle);

      // Color code by signal strength: Green (>30), Orange (15-30), Red (<15)
      const color = sat.signalStrength > 30 ? '#22c55e' : sat.signalStrength > 15 ? '#f97316' : '#ef4444';
      
      // Draw satellite dot
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.arc(x, y, 6, 0, Math.PI * 2);
      ctx.fill();

      // Draw satellite pulse
      ctx.strokeStyle = color;
      ctx.lineWidth = 2;
      ctx.globalAlpha = 0.5;
      ctx.beginPath();
      ctx.arc(x, y, 10, 0, Math.PI * 2);
      ctx.stroke();
      ctx.globalAlpha = 1;

      // Draw satellite name
      ctx.fillStyle = color;
      ctx.font = '9px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(sat.name, x, y - 15);
    });

    // Draw center point
    ctx.fillStyle = '#00ff00';
    ctx.beginPath();
    ctx.arc(centerX, centerY, 3, 0, Math.PI * 2);
    ctx.fill();

  }, [satellites, rotation]);

  return (
    <div className="relative">
      <canvas
        ref={canvasRef}
        width={470}
        height={400}
        className="bg-black/80 rounded-lg border-2 border-green-500/50"
        style={{ imageRendering: 'crisp-edges' }}
      />
      <div className="absolute top-4 left-4 bg-black/70 px-3 py-2 rounded border border-green-500/50">
        <div className="text-green-400 text-sm font-mono">
          TRACKING: {satellites.length} SATELLITES
        </div>
      </div>
    </div>
  );
}
