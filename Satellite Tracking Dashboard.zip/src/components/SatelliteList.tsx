import { motion } from 'motion/react';
import { Satellite } from 'lucide-react';

interface SatelliteData {
  id: string;
  name: string;
  azimuth: number;
  elevation: number;
  signalStrength: number;
}

interface SatelliteListProps {
  satellites: SatelliteData[];
}

export function SatelliteList({ satellites }: SatelliteListProps) {
  return (
    <div className="bg-black/80 rounded-lg border-2 border-green-500/50 p-3 h-full overflow-y-auto">
      <div className="flex items-center gap-2 mb-3">
        <Satellite className="text-green-400" size={16} />
        <h3 className="text-green-400 font-mono text-sm">SATELLITES ({satellites.length})</h3>
      </div>
      <div className="space-y-2">
        {satellites.map((sat, index) => {
          const signalColor = sat.signalStrength > 30 ? 'text-green-400' : sat.signalStrength > 15 ? 'text-orange-400' : 'text-red-400';
          const bgColor = sat.signalStrength > 30 ? 'bg-green-500' : sat.signalStrength > 15 ? 'bg-orange-500' : 'bg-red-500';
          
          return (
            <motion.div
              key={sat.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.02 }}
              className="bg-green-950/20 border border-green-500/20 rounded p-2"
            >
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-2">
                  <div className={`w-2 h-2 rounded-full ${bgColor}`} />
                  <div className="text-green-300 font-mono text-xs">{sat.name}</div>
                </div>
                <div className={`text-xs font-mono ${signalColor}`}>{sat.signalStrength.toFixed(0)} dB</div>
              </div>
              <div className="flex items-center gap-3 text-xs">
                <div>
                  <span className="text-green-600">AZ:</span>
                  <span className="text-green-400 ml-1 font-mono">{sat.azimuth.toFixed(0)}°</span>
                </div>
                <div>
                  <span className="text-green-600">EL:</span>
                  <span className="text-green-400 ml-1 font-mono">{sat.elevation.toFixed(0)}°</span>
                </div>
                <div className="flex-1">
                  <div className="w-full bg-green-950/50 rounded-full h-1.5 overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${(sat.signalStrength / 50) * 100}%` }}
                      transition={{ duration: 0.5, delay: index * 0.02 }}
                      className={`h-full rounded-full ${bgColor}`}
                    />
                  </div>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
