import { motion } from 'motion/react';
import { Cloud, CloudRain, CloudSnow, Sun, Wind, Droplets } from 'lucide-react';

interface WeatherBoxProps {
  condition: 'sunny' | 'cloudy' | 'rainy' | 'snowy' | 'windy';
  temperature: number;
  humidity: number;
  pressure: number;
}

export function WeatherBox({ condition, temperature, humidity, pressure }: WeatherBoxProps) {
  const getWeatherAnimation = () => {
    switch (condition) {
      case 'sunny':
        return (
          <div className="relative w-full h-full flex items-center justify-center overflow-hidden">
            <motion.div
              animate={{
                rotate: 360,
                scale: [1, 1.1, 1],
              }}
              transition={{
                rotate: { duration: 20, repeat: Infinity, ease: 'linear' },
                scale: { duration: 2, repeat: Infinity, ease: 'easeInOut' },
              }}
            >
              <Sun className="text-yellow-400" size={48} />
            </motion.div>
            {[...Array(8)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-1 h-1 bg-yellow-300 rounded-full"
                style={{
                  left: `${50 + 40 * Math.cos((i * Math.PI * 2) / 8)}%`,
                  top: `${50 + 40 * Math.sin((i * Math.PI * 2) / 8)}%`,
                }}
                animate={{
                  scale: [0, 1.5, 0],
                  opacity: [0, 1, 0],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  delay: i * 0.25,
                }}
              />
            ))}
          </div>
        );
      case 'cloudy':
        return (
          <div className="relative w-full h-full flex items-center justify-center">
            {[0, 1, 2].map((i) => (
              <motion.div
                key={i}
                className="absolute"
                animate={{
                  x: [-20, 20, -20],
                  y: [0, -5, 0],
                }}
                transition={{
                  duration: 4 + i,
                  repeat: Infinity,
                  ease: 'easeInOut',
                  delay: i * 0.5,
                }}
                style={{ left: `${20 + i * 20}%` }}
              >
                <Cloud className="text-gray-400" size={40 - i * 8} />
              </motion.div>
            ))}
          </div>
        );
      case 'rainy':
        return (
          <div className="relative w-full h-full flex items-center justify-center overflow-hidden">
            <CloudRain className="text-blue-400 z-10" size={48} />
            {[...Array(20)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-0.5 h-3 bg-blue-300 rounded-full"
                style={{
                  left: `${Math.random() * 100}%`,
                }}
                animate={{
                  y: [0, 120],
                  opacity: [0, 1, 0],
                }}
                transition={{
                  duration: 1,
                  repeat: Infinity,
                  delay: Math.random() * 2,
                  ease: 'linear',
                }}
              />
            ))}
          </div>
        );
      case 'snowy':
        return (
          <div className="relative w-full h-full flex items-center justify-center overflow-hidden">
            <CloudSnow className="text-blue-200 z-10" size={48} />
            {[...Array(15)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-2 h-2 bg-white rounded-full"
                style={{
                  left: `${Math.random() * 100}%`,
                }}
                animate={{
                  y: [0, 120],
                  x: [-10, 10, -10],
                  opacity: [0, 1, 0],
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  delay: Math.random() * 3,
                  ease: 'easeInOut',
                }}
              />
            ))}
          </div>
        );
      case 'windy':
        return (
          <div className="relative w-full h-full flex items-center justify-center overflow-hidden">
            <Wind className="text-gray-300 z-10" size={48} />
            {[...Array(5)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute h-0.5 bg-gray-400 rounded-full"
                style={{
                  top: `${30 + i * 15}%`,
                  width: `${40 + Math.random() * 20}%`,
                }}
                animate={{
                  x: [-100, 200],
                  opacity: [0, 1, 0],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  delay: i * 0.3,
                  ease: 'easeInOut',
                }}
              />
            ))}
          </div>
        );
    }
  };

  const getBgColor = () => {
    switch (condition) {
      case 'sunny':
        return 'bg-gradient-to-br from-yellow-900/30 to-orange-900/30 border-yellow-500/50';
      case 'cloudy':
        return 'bg-gradient-to-br from-gray-800/30 to-gray-700/30 border-gray-500/50';
      case 'rainy':
        return 'bg-gradient-to-br from-blue-900/30 to-blue-800/30 border-blue-500/50';
      case 'snowy':
        return 'bg-gradient-to-br from-blue-950/30 to-cyan-900/30 border-cyan-500/50';
      case 'windy':
        return 'bg-gradient-to-br from-gray-700/30 to-slate-700/30 border-slate-500/50';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className={`rounded-lg border-2 p-3 ${getBgColor()}`}
    >
      <div className="h-24">{getWeatherAnimation()}</div>
      <div className="mt-3 space-y-1.5">
        <div className="flex items-center justify-between">
          <span className="text-gray-400 text-xs">Temperature</span>
          <span className="text-white font-mono text-sm">{temperature}°C</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-gray-400 text-xs flex items-center gap-1">
            <Droplets size={12} /> Humidity
          </span>
          <span className="text-white font-mono text-sm">{humidity}%</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-gray-400 text-xs">Pressure</span>
          <span className="text-white font-mono text-sm">{pressure} hPa</span>
        </div>
      </div>
    </motion.div>
  );
}
